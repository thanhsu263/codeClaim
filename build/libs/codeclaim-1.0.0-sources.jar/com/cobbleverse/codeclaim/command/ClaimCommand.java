package com.cobbleverse.codeclaim.command;

import com.cobbleverse.codeclaim.CodeClaim;
import com.cobbleverse.codeclaim.config.CodeEntry;
import com.cobbleverse.codeclaim.config.ConfigManager;
import com.cobbleverse.codeclaim.data.PlayerDataManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Lệnh /claim <code>  - tất cả người chơi đều dùng được (permission level 0)
 * Lệnh /claimadmin reload - chỉ OP mới dùng được (permission level 2)
 */
public class ClaimCommand {

    private static PlayerDataManager dataManager;

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dataManager = new PlayerDataManager();
        dataManager.load();

        // /claim <code>  — mọi người chơi
        dispatcher.register(
            class_2170.method_9247("claim")
                .requires(src -> src.method_43737()) // phải là player, không phải console
                .then(
                    class_2170.method_9244("code", StringArgumentType.word())
                        .executes(ctx -> executeClaim(ctx, StringArgumentType.getString(ctx, "code")))
                )
        );

        // /claimadmin reload  — chỉ OP level 2
        dispatcher.register(
            class_2170.method_9247("claimadmin")
                .requires(src -> src.method_9259(2))
                .then(
                    class_2170.method_9247("reload")
                        .executes(ClaimCommand::executeReload)
                )
                .then(
                    class_2170.method_9247("info")
                        .then(
                            class_2170.method_9244("code", StringArgumentType.word())
                                .executes(ctx -> executeInfo(ctx, StringArgumentType.getString(ctx, "code")))
                        )
                )
        );
    }

    // ─── /claim <code> ───────────────────────────────────────────────────────

    private static int executeClaim(CommandContext<class_2168> ctx, String inputCode) {
        class_2168 source = ctx.getSource();
        class_3222 player;
        try {
            player = source.method_9207();
        } catch (Exception e) {
            return 0;
        }

        ConfigManager cfg = CodeClaim.configManager;

        // Tìm code khớp (không phân biệt hoa thường)
        String matchedKey = null;
        CodeEntry entry = null;
        for (String key : cfg.codes.keySet()) {
            if (key.equalsIgnoreCase(inputCode)) {
                matchedKey = key;
                entry = cfg.codes.get(key);
                break;
            }
        }

        if (matchedKey == null || entry == null) {
            sendMessage(player, cfg.msgInvalidCode.replace("{code}", inputCode));
            return 0;
        }

        // Kiểm tra player đã nhập chưa
        if (dataManager.hasRedeemed(player.method_5667(), matchedKey)) {
            sendMessage(player, cfg.msgAlreadyClaimed.replace("{code}", inputCode));
            return 0;
        }

        // Kiểm tra giới hạn tổng số lần dùng
        if (entry.maxUses > 0 && dataManager.getUsageCount(matchedKey) >= entry.maxUses) {
            sendMessage(player, cfg.msgMaxUses.replace("{code}", inputCode));
            return 0;
        }

        // Thực thi lệnh thưởng
        for (String cmd : entry.commands) {
            String formatted = cmd.replace("%player%", player.method_5477().getString());
            try {
                source.method_9211().method_3734()
                        .method_44252(source.method_9211().method_3739(), formatted);
            } catch (Exception e) {
                CodeClaim.LOGGER.error("[CodeClaim] Lỗi khi chạy lệnh '{}': {}", formatted, e.getMessage());
            }
        }

        // Ghi nhận
        dataManager.markRedeemed(player.method_5667(), matchedKey);
        sendMessage(player, cfg.msgSuccess.replace("{code}", inputCode));

        CodeClaim.LOGGER.info("[CodeClaim] {} đã nhập code '{}'", player.method_5477().getString(), matchedKey);
        return 1;
    }

    // ─── /claimadmin reload ───────────────────────────────────────────────────

    private static int executeReload(CommandContext<class_2168> ctx) {
        CodeClaim.configManager.load();
        dataManager.load();
        ctx.getSource().method_9226(
            () -> class_2561.method_43470(colorize(CodeClaim.configManager.msgReloaded)), false);
        return 1;
    }

    // ─── /claimadmin info <code> ──────────────────────────────────────────────

    private static int executeInfo(CommandContext<class_2168> ctx, String code) {
        ConfigManager cfg = CodeClaim.configManager;
        CodeEntry entry = null;
        String matchedKey = null;
        for (String k : cfg.codes.keySet()) {
            if (k.equalsIgnoreCase(code)) { matchedKey = k; entry = cfg.codes.get(k); break; }
        }
        if (entry == null) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("§cCode không tồn tại: " + code), false);
            return 0;
        }
        int used = dataManager.getUsageCount(matchedKey);
        String maxStr = entry.maxUses < 0 ? "∞" : String.valueOf(entry.maxUses);
        final String finalKey = matchedKey;
        final CodeEntry finalEntry = entry;
        final String msg = "§6[CodeClaim] §eCode: §f" + finalKey + "\n" +
            "§eĐã dùng: §f" + used + " / " + maxStr + "\n" +
            "§eLệnh: §f" + String.join(", ", finalEntry.commands);
        ctx.getSource().method_9226(() -> class_2561.method_43470(msg), false);
        return 1;
    }

    // ─── Helper ───────────────────────────────────────────────────────────────

    private static void sendMessage(class_3222 player, String raw) {
        player.method_7353(class_2561.method_43470(colorize(raw)), false);
    }

    /** Chuyển &x và §x thành màu Minecraft */
    private static String colorize(String s) {
        return s.replace("&", "§");
    }
}
